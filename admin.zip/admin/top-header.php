
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Medical Equipment| Dashboard</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="<?php echo $_SESSION['base_url']?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/AdminLTE.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $_SESSION['base_url']?>css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

    </head>
    <body class="skin-black">